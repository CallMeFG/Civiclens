<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Category extends Model
{
    use HasFactory;

    protected $fillable = [
        'nama_kategori',
        'slug',
    ];

    // Relasi: Satu Kategori memiliki banyak Laporan
    public function reports()
    {
        return $this->hasMany(Report::class);
    }
}
